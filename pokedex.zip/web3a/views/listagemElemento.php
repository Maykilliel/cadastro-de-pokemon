<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pokédex</title>
    <style>
        body {
            background-color: #f8f9fa;
            padding-top: 56px; 
        }
        .container {
            padding-top: 20px;
        }
        .card {
            margin-bottom: 20px;
        }
        .card-header {
            background-color: #d32f2f; 
            color: #fff; 
        }
        .table {
            border-collapse: separate;
            border-spacing: 0;
            width: 100%;
            background-color: #fff; 
            border: 1px solid #dee2e6; 
            border-radius: 0.25rem;
        }
        .table th,
        .table td {
            padding: 0.75rem;
            vertical-align: top;
            border-top: 1px solid #dee2e6; 
        }
        .table thead th {
            vertical-align: bottom;
            border-bottom: 2px solid #dee2e6; 
            background-color: #f8f9fa; 
        }
        .table tbody+tbody {
            border-top: 2px solid #dee2e6; 
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="card">
            <div class="card-header">
                <h1 class="text-center">Lista Tipos</h1>
                <a class="btn btn-primary" href="novo" style="background-color: rgb(184, 134, 11);">Novo</a>
            </div>
            <div class="card-body">
                <table class="table table-striped table-bordered">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Descrição</th>
                            <th scope="col">Excluir</th>
                            <th scope="col">Editar</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php

                    function compararPorId($a, $b) {
                        return $a['id'] - $b['id'];
                    }
                    usort($dados, 'compararPorId');
                
                    foreach ($dados as $elementos) {
                    echo "
                    <tr>
                        <th scope='row'>{$elementos['id']}</th>
                        <td>{$elementos['descricao']}</td>
                        <td><a href='excluir/{$elementos['id']}' class='btn btn-danger'>-</a></td>
                        <td><a href='alterar/{$elementos['id']}' class='btn btn-primary'>+</a></td>
                    </tr>";                          
                }
            ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>
</html>

