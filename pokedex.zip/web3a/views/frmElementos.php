<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulário Tipos</title>
    <style>
        body {
            background-color: #f8f9fa;
            padding-top: 56px; 
        }
        .container {
            padding-top: 20px;
        }
        form {
            max-width: 400px;
            margin: 0 auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
        }
        .form-label {
            font-weight: bold;
        }
        .form-control {
            margin-bottom: 10px;
        }
        .form-floating {
            margin-bottom: 10px;
        }
        .btn-primary {
            background-color: #007bff;
            border-color: #007bff;
        }
        .btn-primary:hover {
            background-color: #0069d9;
            border-color: #0062cc;
        }
        .cadastroT {
            display: flex;
            justify-content: center;
            max-width: 400px;
            margin: 0 auto;
            background-color: red;
            border-radius: 80px;
        }
        img.cadastroT{
            width: 70%;
            height: 70%;
        }
    </style>
</head>
<body>
    <div>
<div class="cadastroT">
        <img src="http://localhost/web3a/views/uploads/cadastrar.png" alt="cadastrar" class = "cadastroT">
    </div>
    <div class="container">
        <form action="<?php echo APP. 'elementos/salvar'; ?>" method="POST">
            <div class="mb-3">
                <label for="id" class="form-label">ID</label>
                <input readonly type="text" class="form-control" id="id" name="id" value="<?php echo $dados['id'];?>">
            </div>
            <div class="mb-3">
                <label for="descricao" class="form-label">Descrição</label>
                <input type="text" class="form-control" maxlength="11" id="descricao" name="descricao" value="<?php echo $dados['descricao'];?>">
            </div>
            <button type="submit" class="btn btn-primary">Salvar</button>
        </form>
    </div>
    </div>
</body>
</html>
