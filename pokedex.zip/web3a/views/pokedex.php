<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pokédex</title>
    <style>
        *{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        .bodypokedex{
            text-align: center;
        }
        .mainpokedex{
            display: inline-block;
            margin-top: 2%;
            position: relative;
        }
        .pokedex{
            width: 100%;
            max-width: 350px;
        }
        .pokemon_imagem{
            position: absolute;
            bottom: 55%;
            left: 50%;
            transform: translate(-63%, 20%);
            height: 18%;
        }
        .pokemon_data{
            position: absolute;
            color: #aaa;
            top: 54.5%;
            right: 27%;
            font-size: clamp(8px, 5vw, 25px);
        }
        .pokemon_name{
            color: #3a444d;
            text-transform: capitalize;
        }
        .pokemon_descricao{
            position: absolute;
            background-color: white;
            top: 65%;
            right: 20%;
            height: 25%;
            width: 100%;
            max-width: 68%;
            border-radius: 10%;
            font-size: clamp(4px, 2.5vw, 18px);
            box-shadow: 0px 4px 20px rgba(0.5, 0.5, 0.5, 0.5);
        }
    </style>
</head>
<body>
<div class = "bodypokedex">
<main class="mainpokedex">
    <?php foreach ($dados as $pokemon) {
        if ($pokemon['id'] == $id) {
            $data = date('d/m/Y', strtotime($pokemon['data']));
            echo "
                <img src='http://localhost/web3a/".$pokemon['foto']."' alt='poke imagem' class='pokemon_imagem'>
                <h1 class='pokemon_data'>
                    <span class='pokemon_number'>{$pokemon['id']}</span> -
                    <span class='pokemon_name'>{$pokemon['nome']}</span>
                </h1>

                <div class = 'pokemon_descricao'>
                <p>
                <span>{$pokemon['treinador']}</span>        
                <span style='margin-left: 90px;'>$data</span>
                </p>
                <p;>
                Tipo: {$pokemon['elementos_descricao']}
                </p>
                <p>
                {$pokemon['descricao']}
                </p>
            </div>

            ";
        }
    } ?>
    <img src="http://localhost/web3a/views/uploads/pokedeximg.png" alt="pokedex" class="pokedex">
</main>
</div>

</body>
</html>
