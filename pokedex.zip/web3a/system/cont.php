<?php
  class Controller {
    function view($visao, $parameters) {
      extract($parameters);
      include_once "web3a/template.php";   
    }
    function redirect($path) {
        header('location: '.APP.$path);
    }
  }
?>