<?php
  class ElementosController extends Controller {
    function listar() {
      $model = new Elementos();
      $dados = $model->all();
      $this->view("listagemElemento", compact('dados'));
    }
    function novo() {
      $dados = array();
      $dados['id'] = 0;
      $dados['descricao'] = "";
      $this->view("frmElementos", compact('dados'));
    }    

    function salvar() {
      $dados = array();
      $dados['id'] = $_POST['id'];
      $dados['descricao'] = $_POST['descricao'];
      $model = new Elementos();
      if ($dados['id'] == 0) {
        $model->create($dados);
      } else {
        $model->update($dados);
      }

      $this->redirect('elementos/listar');
    }
    function excluir($id) {
      $model = new Elementos();
      $dados = $model->getById($id);
      $model->delete($id);

      $this->redirect('elementos/listar');
    }
    function alterar($id) {
      $model = new Elementos();
      $dados = $model->getById($id);
      $this->view("frmElementos", compact('dados'));
    }

  }
?>