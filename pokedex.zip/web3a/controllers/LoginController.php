<?php
class LoginController extends Controller {
    function login() {
        $this->view('frmLogin', ['mensagem' => '']);
    }
    
    function logar() {
        $email = $_POST['email'];
        $senha = $_POST['senha'];
        $model = new Usuario();
        $dados = $model->getByEmail($email);
        
        if (!$dados || $dados['senha'] != $senha) {
        $this->redirect('login/login?mensagem=Email ou senha inválidos');
        } else {
            session_start();
            $_SESSION['treinador_id'] = $dados['id'];
            $this->redirect("/");
        }
    }
    
    function logout() {
        session_start();
        session_destroy();
        $this->redirect("login/login");
    }
}
?>
