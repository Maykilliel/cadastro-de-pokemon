<?php
  class Elementos extends Model {
    protected $table = "elementos";
    protected $orderBy = "descricao";
  }
?>