<?php
  class Pokemon extends Model {
    protected $sql = "SELECT pokemon.*, elementos.descricao AS elementos_descricao FROM pokemon LEFT JOIN elementos ON elementos.id = pokemon.elementos_id ORDER BY data DESC, id";
    protected $table = "pokemon";
    protected $orderBy = "data DESC, id";    
  }
?>