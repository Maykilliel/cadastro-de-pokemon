<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet">
    <title>Página Inicial de Pokémon</title>
    <style>
        header {
            background-color: #e60000;
            color: #fff;
            text-align: center;
            margin: 0;
        }
        h1 {
            margin: 0;
        }
        section {
            padding: 20px;
        }
    </style>
</head>
<body>

<header>
    <h1>Bem-vindo ao Mundo Pokémon!</h1>
</header>


<section>
    <h2>Sobre Pokémon</h2>
    <p>Pokémon são criaturas de todas as formas e tamanhos que vivem na natureza ou ao lado dos humanos. Atualmente, existem mais de 800 espécies de Pokémon.</p>
    <p>Os Pokémon são criados e comandados por seus proprietários (chamados "Treinadores"). Durante suas aventuras, os Treinadores usam os Pokémon para batalhar contra outros Treinadores de Pokémon e para alcançar outros objetivos.</p>
</section>

</body>
</html>
