<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Acesso ao Sistema</title>
    <style>
        form {
            max-width: 400px;
            margin: 0 auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
        }
        .form-label {
            font-weight: bold;
        }
        .form-control {
            margin-bottom: 10px;
        }
        .btn-primary {
            background-color: #007bff;
            border-color: #007bff;
        }
        .btn-primary:hover {
            background-color: #0069d9;
            border-color: #0062cc;
        }
        .alert {
            margin-bottom: 20px;
        }

        .welcome {
            margin-bottom: 1% !important;
            display: flex;
            justify-content: center;
            max-width: 400px;
            margin: 0 auto;
            background-color: red;
            border-radius: 80px;
        }
        img.welcome{
            width: 70%;
            height: 70%;
        }
    </style>
</head>
<body>
    <div class="container">
        <?php
        if ($mensagem != "") {
            echo " 
            <div class='alert alert-success' >
                $mensagem
            </div>                    
            ";
        }
        ?>
            <div class="welcome">
        <img src="/web3a/views/uploads/Welcome.png" alt="welcome" class = "welcome">
    </div>
        <form action="<?php echo APP. 'login/logar'; ?>" method="POST">
            <div class="mb-3">
                <label for="email" class="form-label">E-mail</label>
                <input type="email" class="form-control" id="email" name="email">
            </div>
            <div class="mb-3">
                <label for="senha" class="form-label">Senha</label>
                <input type="password" class="form-control" id="senha" name="senha">
            </div>
            <button type="submit" class="btn btn-primary">Entrar</button>
        </form>
    </div>
</body>
</html>
