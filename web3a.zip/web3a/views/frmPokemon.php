<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulário de Pokemon</title>
    <style>
        body {
            background-color: #f8f9fa;
            padding-top: 56px; 
        }
        .container {
            padding-top: 20px;
        }
        form {
            max-width: 400px;
            margin: 0 auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
        }
        .form-label {
            font-weight: bold;
        }
        .form-control {
            margin-bottom: 10px;
        }
        .form-floating {
            margin-bottom: 10px;
        }
        .btn-primary {
            background-color: #007bff;
            border-color: #007bff;
        }
        .btn-primary:hover {
            background-color: #0069d9;
            border-color: #0062cc;
        }
        .cadastrarP {
            display: flex;
            justify-content: center;
            max-width: 400px;
            margin: 0 auto;
            background-color: red;
            border-radius: 70px;
        }
        img.cadastrarP{
            width: 70%;
            height: 70%;
        }
    </style>
</head>
<body>
    <div>
    <div class = "cadastrarP">
    <img src="/web3a/views/uploads/cadastro.png" alt="cadastrar" class = "cadastrarP">
    </div>
    <div class="container">
        <form action="<?php echo APP. 'pokemon/salvar'; ?>" enctype="multipart/form-data" method="POST">
            <div class="mb-3">
                <label for="id" class="form-label">ID</label>
                <input readonly type="text" class="form-control" id="id" name="id" value="<?php echo $dados['id'];?>">
            </div>

            <div class="mb-3">
                <label for="elementos_id" class="form-label">Elementos</label>
                <select class="form-select" id="elementos_id" name="elementos_id">
                    <?php
                        foreach ($elemento as $elementos) {
                            $selected = $elementos['id']==$dados['elementos_id']?'selected':'';
                            echo "<option $selected value='{$elementos['id']}'>{$elementos['descricao']}</option>";  
                        }
                    ?>
                </select>    
            </div>
            <div class="mb-3">
                <label for="foto" class="form-label">foto</label>
                <input type="file" placeholder="Foto" name="foto" value="<?php echo $dados['foto'];?>">
            </div>
            <div class="mb-3">
                <label for="data" class="form-label">Data</label>
                <input type="date" class="form-control" id="data" name="data" value="<?php echo $dados['data'];?>">
            </div>
            <div class="mb-3">
                <label for="treinador" class="form-label">Treinador do pokemon</label>
                <input type="text" class="form-control" id="treinador" name="treinador" maxlength="9" value="<?php echo $dados['treinador'];?>">
            </div>
            <div class="mb-3">
                <label for="nome" class="form-label">Nome do Pokemon</label>
                <input type="text" class="form-control" id="nome" name="nome" maxlength="9" required value="<?php echo $dados['nome'];?>">
            </div>
            <div class="form-floating mb-3">
                <textarea class="form-control" id="descricao" maxlength="60" style="height: 100px" name="descricao" ><?php echo $dados['descricao'];?></textarea>
                <label for="descricao">Descrição</label>
            </div>
            <button type="submit" class="btn btn-primary">Salvar</button>
        </form>
    </div>
    </div>
</body>
</html>
