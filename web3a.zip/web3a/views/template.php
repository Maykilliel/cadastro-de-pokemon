<!DOCTYPE html>
<html lang="en" data-bs-theme="auto">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Hugo 0.122.0">
    <title>Fixed top navbar example · Bootstrap v5.3</title>

    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet">
    <style>
         body {
            padding-top: 56px;
            background-image: url('/web3a/views/uploads/wallpaperPoke.png');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            background-attachment: fixed;
        }
        body {
            padding-top: 56px;
            background-color: #f8f9fa;
        }
        main {
            padding: 20px;
            background-color: rgba(255, 255, 255, 0.0); 
            border-radius: 1S0px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0);
        }
        .bg-body-tertiary {
            background-color: transparent !important;
            border-radius: 0px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0);       
         }
        footer {
            background-color: #333; 
            color: #fff; 
            text-align: center; 
            padding: 10px 0; 
            position: fixed; 
            bottom: 0; 
            left: 0;
            width: 100%; 
        }      

        img.logo {
            width: 20%;
            height: 20%;
        }

        .navbar-nav {
            margin-left: auto;
        }
    </style>
</head>
<body>
    
    <nav class="navbar navbar-expand-md navbar-dark fixed-top" style="background-color: #333;"> 
        <div class="container-fluid d-flex justify-content-between align-items-center">
            <div class="logo"> 
            <a href="<?php echo APP; ?>">
    <img src="/web3a/views/uploads/pokelogo.png" alt="logo" class="logo">
</a>            
</div>
            <a class="navbar-brand" href="<?php echo APP; ?>">Home</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarCollapse">
                <ul class="navbar-nav me-auto mb-2 mb-md-0">
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="<?php echo APP.'pokemon/listar'; ?>">Pokemons</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="<?php echo APP.'elementos/listar'; ?>">Tipos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="<?php echo APP.'login/logout'; ?>">Sair</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <main class="container" >
        <div class="bg-body-tertiary p-5 rounded">
            <?php include_once 'views/'.$visao.'.php'; ?>
        </div>
    </main>

    <footer>
        &copy; 2024 Pokémon. Todos os direitos reservados.
    </footer>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
</body>
</html>
