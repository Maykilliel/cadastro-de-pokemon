<?php   
  class IndexController extends Controller {
    function index() {
        $this->view('index', []);
    }
  }
?>