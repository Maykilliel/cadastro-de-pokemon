<?php
class Imagem {
    private $pathPasta;
    private $nomeArquivo;

    function __construct($nomepasta) {
        $this->pathPasta = $nomepasta;
    }

    function __get($prop) {
        return $this->$prop;
    }
    
    function gravarImagemPost($nomeImagem) {
        if ($_FILES[$nomeImagem]["tmp_name"] == null || !is_uploaded_file($_FILES[$nomeImagem]["tmp_name"])) {
            return false;
        }

        $tiposPermitidos = ['image/jpeg', 'image/png', 'image/gif', 'image/jpg']; 
        $check = getimagesize($_FILES[$nomeImagem]["tmp_name"]);
        if ($check === false || !in_array($check['mime'], $tiposPermitidos)) {
            return false;
        }

        if (!file_exists($this->pathPasta)) {
            mkdir($this->pathPasta, 0777, true);
        }

        $nomeUnico = hash('sha256', time() . uniqid(rand(), true)) . '.' . pathinfo($_FILES[$nomeImagem]['name'], PATHINFO_EXTENSION);
        $destino = $this->pathPasta . $nomeUnico;

        $this->nomeArquivo = $destino;

        return move_uploaded_file($_FILES[$nomeImagem]["tmp_name"], $destino);
    }
}

?>