<?php
    require_once(__DIR__ .'/../controllers/imagem.class.php');  


  class PokemonController extends Controller {
    function listar() {

      $model = new Pokemon();
      $dados = $model->all();
      $this->view('listagemPokemon', compact('dados'));
    }

    function listarPokedex($id) {
      $poke = ('web3a/pokedex.php');
      $model = new Pokemon();
      $dados = $model->all($id);
      $this->view('pokedex', compact('dados', 'id'));
    }

    function alterar($id) {
      $model = new Pokemon();
      $dados = $model->getById($id);
      $modelElementos = new Elementos();
      $elemento = $modelElementos->all();     
      $this->view('frmPokemon', compact('dados', 'elemento')) ;
    }
    function excluir($id) {
        $model = new Pokemon();
        $model->delete($id);
        

        $this->redirect('pokemon/listar'); 
        
      }

    function novo() {
      
      $dados = array();
      $dados['id'] = 0;
      $dados['foto'] = "";
      $dados['elementos_id'] = "";
      $dados['data'] = date("Y-m-d");
      $dados['treinador'] = "";
      $dados['nome'] = "";
      $dados['descricao'] = "";
      $modelElementos = new Elementos();
      $elemento = $modelElementos->all();

      $this->view('frmPokemon', compact('dados', 'elemento')) ;

    }

    function salvar() {

      $dados = array();

      $img = new Imagem('views/uploads/pokemons/');
      $temImagem = $img->gravarImagemPost('foto');


      $dados['id'] = $_POST['id'];
      $dados['foto'] = $_post['foto'];
      $dados['elementos_id'] = $_POST['elementos_id'];
      $dados['data'] = $_POST['data'];
      $dados['treinador'] = $_POST['treinador'];
      $dados['nome'] = $_POST['nome'];
      $dados['descricao'] = $_POST['descricao'];
      
      $dados['foto'] = $temImagem? $img->nomeArquivo : null;

      $model = new Pokemon();
      if ($dados['id'] == 0) {
          $model->create($dados);
      } else {
          $model->update($dados);
      }

      
      $this->redirect('pokemon/listar');
  }
  
}
?>
